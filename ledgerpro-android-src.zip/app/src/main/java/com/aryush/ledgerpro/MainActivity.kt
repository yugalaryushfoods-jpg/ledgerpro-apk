package com.aryush.ledgerpro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Base64
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "ledgerpro_native_prefs"
        private const val KEY_SERVER_URL = "saved_ledger_url"
        private const val BG_BIOMETRIC_TIMEOUT_MS = 3 * 60 * 1000L // 3 minutes in background
    }

    private lateinit var webView: WebView
    private lateinit var topProgressBar: ProgressBar
    private lateinit var setupOverlay: LinearLayout
    private lateinit var offlineOverlay: LinearLayout
    private lateinit var biometricShieldOverlay: LinearLayout
    private lateinit var inputServerUrl: EditText
    private lateinit var txtSetupError: TextView

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null
    private var pendingChooserAccepts: String = "image/*"

    private var biometricUnlocked = false
    private var biometricPromptShowing = false
    private var lastPausedAtMs = 0L
    private var lastHistoryBackAtMs = 0L
    private var lastRootExitWarnAtMs = 0L
    private var pageLoadedOnce = false

    // Activity Result: File / Camera / JSON Picker for WebView <input type="file">
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult

        if (result.resultCode != Activity.RESULT_OK) {
            callback.onReceiveValue(null)
            return@registerForActivityResult
        }

        val data = result.data
        val uris = mutableListOf<Uri>()
        if (data != null) {
            val single = data.data
            val clip = data.clipData
            if (single != null) {
                uris.add(single)
            } else if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    clip.getItemAt(i)?.uri?.let { uris.add(it) }
                }
            }
        }
        if (uris.isEmpty() && cameraPhotoUri != null) {
            uris.add(cameraPhotoUri!!)
        }

        if (uris.isNotEmpty()) {
            callback.onReceiveValue(uris.toTypedArray())
        } else {
            callback.onReceiveValue(null)
        }
    }

    // Activity Result: Runtime Camera Permission for Bahi-Khata Scanner
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchDirectCameraCapture()
        } else {
            launchGalleryOrDocumentPicker(pendingChooserAccepts)
        }
    }

    // Activity Result: Native Android Speech-to-Text (Hindi / English Dictation)
    private val speechRecognizerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = matches?.firstOrNull()?.trim().orEmpty()
            if (spoken.isNotEmpty()) {
                val safeJsonStr = JSONObject.quote(spoken)
                webView.post {
                    webView.evaluateJavascript(
                        "window.__lpDeliverSpeech && window.__lpDeliverSpeech($safeJsonStr);",
                        null
                    )
                }
                return@registerForActivityResult
            }
        }
        webView.post {
            webView.evaluateJavascript(
                "window.__lpCancelSpeech && window.__lpCancelSpeech();",
                null
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Crisp Material 3 Light Status & Navigation Bars
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.ledgerWebView)
        topProgressBar = findViewById(R.id.topProgressBar)
        setupOverlay = findViewById(R.id.setupOverlay)
        offlineOverlay = findViewById(R.id.offlineOverlay)
        biometricShieldOverlay = findViewById(R.id.biometricShieldOverlay)
        inputServerUrl = findViewById(R.id.inputServerUrl)
        txtSetupError = findViewById(R.id.txtSetupError)

        configureWebView()
        setupOverlayActions()
        setupHardwareBackNavigation()

        val activeUrl = resolveConfiguredUrl()
        if (activeUrl.isEmpty()) {
            showSetupOverlay("")
        } else {
            authenticateBiometricThenLoad(activeUrl)
        }
    }

    override fun onPause() {
        super.onPause()
        lastPausedAtMs = System.currentTimeMillis()
        CookieManager.getInstance().flush()
    }

    override fun onResume() {
        super.onResume()
        val activeUrl = resolveConfiguredUrl()
        if (activeUrl.isEmpty() || setupOverlay.visibility == View.VISIBLE) return

        val awayMs = if (lastPausedAtMs > 0L) System.currentTimeMillis() - lastPausedAtMs else 0L
        if (!biometricUnlocked || awayMs > BG_BIOMETRIC_TIMEOUT_MS) {
            biometricUnlocked = false
            authenticateBiometricThenLoad(null)
        }
    }

    private fun resolveConfiguredUrl(): String {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_SERVER_URL, "")?.trim().orEmpty()
        if (saved.isNotEmpty()) return saved

        val baked = BuildConfig.DEFAULT_LEDGER_URL.trim()
        if (baked.isNotEmpty()) {
            val normalized = normalizeServerUrl(baked)
            if (normalized != null) {
                prefs.edit().putString(KEY_SERVER_URL, normalized).apply()
                return normalized
            }
        }
        return ""
    }

    private fun normalizeServerUrl(rawInput: String): String? {
        var s = rawInput.trim().replace(" ", "")
        if (s.isEmpty()) return null
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "https://$s"
        }
        if (s.startsWith("http://")) {
            s = "https://" + s.removePrefix("http://")
        }
        while (s.endsWith("/")) {
            s = s.dropLast(1)
        }
        val parsed = Uri.parse(s)
        val host = parsed.host.orEmpty()
        if (!host.contains(".") || host.length < 4) return null
        return s
    }

    private fun showSetupOverlay(prefill: String) {
        setupOverlay.visibility = View.VISIBLE
        offlineOverlay.visibility = View.GONE
        biometricShieldOverlay.visibility = View.GONE
        txtSetupError.visibility = View.GONE
        if (prefill.isNotEmpty()) {
            inputServerUrl.setText(prefill)
            inputServerUrl.setSelection(prefill.length)
        }
    }

    private fun setupOverlayActions() {
        findViewById<Button>(R.id.btnConnectServer).setOnClickListener {
            val raw = inputServerUrl.text?.toString().orEmpty()
            val clean = normalizeServerUrl(raw)
            if (clean == null) {
                txtSetupError.text = "Please enter a valid Cloudflare URL (e.g. https://your-app.workers.dev)"
                txtSetupError.visibility = View.VISIBLE
                return@setOnClickListener
            }
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_SERVER_URL, clean)
                .apply()

            setupOverlay.visibility = View.GONE
            authenticateBiometricThenLoad(clean)
        }

        findViewById<Button>(R.id.btnRetryConnection).setOnClickListener {
            offlineOverlay.visibility = View.GONE
            val url = resolveConfiguredUrl()
            if (url.isNotEmpty()) {
                webView.loadUrl(url)
            }
        }

        findViewById<Button>(R.id.btnChangeServerUrl).setOnClickListener {
            showSetupOverlay(resolveConfiguredUrl())
        }

        findViewById<Button>(R.id.btnUnlockBiometric).setOnClickListener {
            val targetUrl = if (!pageLoadedOnce) resolveConfiguredUrl() else null
            authenticateBiometricThenLoad(targetUrl)
        }
    }

    private fun getSupportedAuthenticators(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BIOMETRIC_STRONG or BIOMETRIC_WEAK or DEVICE_CREDENTIAL
        } else {
            BIOMETRIC_WEAK or DEVICE_CREDENTIAL
        }
    }

    private fun authenticateBiometricThenLoad(urlToLoad: String?) {
        val biometricManager = BiometricManager.from(this)
        val authenticators = getSupportedAuthenticators()
        val canAuth = biometricManager.canAuthenticate(authenticators)

        // If phone has no fingerprint/PIN lock configured at OS level, proceed directly to Server PIN screen
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            biometricUnlocked = true
            biometricShieldOverlay.visibility = View.GONE
            if (!urlToLoad.isNullOrEmpty()) {
                pageLoadedOnce = true
                webView.loadUrl(urlToLoad)
            }
            return
        }

        biometricShieldOverlay.visibility = View.VISIBLE
        if (biometricPromptShowing) return
        biometricPromptShowing = true

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                biometricPromptShowing = false
                biometricUnlocked = true
                biometricShieldOverlay.visibility = View.GONE
                if (!urlToLoad.isNullOrEmpty()) {
                    pageLoadedOnce = true
                    webView.loadUrl(urlToLoad)
                }
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                biometricPromptShowing = false
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock LedgerPro")
            .setSubtitle("Verify your fingerprint or phone screen lock")
            .setAllowedAuthenticators(authenticators)
            .build()

        try {
            prompt.authenticate(promptInfo)
        } catch (_: Exception) {
            biometricPromptShowing = false
            biometricUnlocked = true
            biometricShieldOverlay.visibility = View.GONE
            if (!urlToLoad.isNullOrEmpty()) {
                pageLoadedOnce = true
                webView.loadUrl(urlToLoad)
            }
        }
    }

    private fun setupHardwareBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (biometricShieldOverlay.visibility == View.VISIBLE) {
                    finish()
                    return
                }
                if (setupOverlay.visibility == View.VISIBLE) {
                    val saved = resolveConfiguredUrl()
                    if (saved.isNotEmpty() && pageLoadedOnce) {
                        setupOverlay.visibility = View.GONE
                    } else {
                        finish()
                    }
                    return
                }
                if (offlineOverlay.visibility == View.VISIBLE) {
                    finish()
                    return
                }

                if (webView.canGoBack()) {
                    lastHistoryBackAtMs = System.currentTimeMillis()
                    webView.goBack()
                    return
                }

                val now = System.currentTimeMillis()
                if (now - lastHistoryBackAtMs < 2500L || now - lastRootExitWarnAtMs < 2200L) {
                    finish()
                } else {
                    lastRootExitWarnAtMs = now
                    Toast.makeText(this@MainActivity, "Press Back again to exit", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val ws = webView.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.databaseEnabled = true
        ws.allowFileAccess = false
        ws.allowContentAccess = true
        ws.loadsImagesAutomatically = true
        ws.mediaPlaybackRequiresUserGesture = false
        ws.cacheMode = WebSettings.LOAD_DEFAULT
        ws.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        ws.setSupportZoom(false)
        ws.builtInZoomControls = false
        ws.displayZoomControls = false
        ws.userAgentString = ws.userAgentString + " LedgerProAndroid/4.0"

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.addJavascriptInterface(AndroidNativeBridge(), "AndroidBridge")

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, bridgeBootstrapScript, setOf("*"))
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase(Locale.ROOT).orEmpty()
                val host = uri.host?.lowercase(Locale.ROOT).orEmpty()

                if (scheme in listOf("whatsapp", "tel", "mailto", "sms", "intent") ||
                    host == "wa.me" || host == "api.whatsapp.com"
                ) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "Required app not installed on device", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                offlineOverlay.visibility = View.GONE
                view?.evaluateJavascript(bridgeBootstrapScript, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(bridgeBootstrapScript, null)
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    offlineOverlay.visibility = View.VISIBLE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    topProgressBar.visibility = View.VISIBLE
                    topProgressBar.progress = newProgress
                } else {
                    topProgressBar.visibility = View.GONE
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let { req ->
                    runOnUiThread {
                        req.grant(req.resources)
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val isCapture = fileChooserParams?.isCaptureEnabled == true
                val accepts = fileChooserParams?.acceptTypes?.joinToString(",")?.lowercase(Locale.ROOT).orEmpty()
                pendingChooserAccepts = accepts.ifBlank { "image/*" }

                if (isCapture) {
                    val hasCam = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasCam) {
                        launchDirectCameraCapture()
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                } else {
                    launchGalleryOrDocumentPicker(pendingChooserAccepts)
                }
                return true
            }
        }
    }

    private fun createTempCameraImageUri(): Uri? {
        return try {
            val camDir = File(cacheDir, "camera_captures").apply { mkdirs() }
            val photoFile = File(camDir, "khata_scan_${System.currentTimeMillis()}.jpg")
            FileProvider.getUriForFile(this, "${packageName}.fileprovider", photoFile)
        } catch (_: Exception) {
            null
        }
    }

    private fun launchDirectCameraCapture() {
        cameraPhotoUri = createTempCameraImageUri()
        val camIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            cameraPhotoUri?.let { uri ->
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        try {
            fileChooserLauncher.launch(camIntent)
        } catch (_: Exception) {
            launchGalleryOrDocumentPicker("image/*")
        }
    }

    private fun launchGalleryOrDocumentPicker(accepts: String) {
        cameraPhotoUri = null
        val pickerIntent = if (accepts.contains("json")) {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
        } else {
            Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
        }
        try {
            fileChooserLauncher.launch(Intent.createChooser(pickerIntent, "Select File"))
        } catch (_: Exception) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
        }
    }

    // =========================================================================
    // NATIVE JAVASCRIPT BRIDGE: A4 PDF SAVE, WHATSAPP PDF SHARE & HINDI SPEECH
    // =========================================================================
    inner class AndroidNativeBridge {

        @JavascriptInterface
        fun saveBase64ToDownloads(base64Data: String, fileName: String, mimeTypeHint: String) {
            runOnUiThread {
                try {
                    val bytes = decodeDataUriOrBase64(base64Data)
                    val cleanName = sanitizeFileName(fileName, mimeTypeHint)
                    val mime = resolveMimeType(cleanName, mimeTypeHint)

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, cleanName)
                            put(MediaStore.Downloads.MIME_TYPE, mime)
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LedgerPro")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        val resolver = contentResolver
                        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        if (uri != null) {
                            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                            values.clear()
                            values.put(MediaStore.Downloads.IS_PENDING, 0)
                            resolver.update(uri, values, null, null)
                        }
                    } else {
                        val dlDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        dlDir.mkdirs()
                        FileOutputStream(File(dlDir, cleanName)).use { it.write(bytes) }
                    }
                    Toast.makeText(
                        this@MainActivity,
                        "Saved in Downloads/LedgerPro: $cleanName",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "Download error: ${e.localizedMessage}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun shareBase64File(
            base64Data: String,
            fileName: String,
            mimeTypeHint: String,
            shareTitle: String,
            shareText: String
        ) {
            runOnUiThread {
                try {
                    val bytes = decodeDataUriOrBase64(base64Data)
                    val cleanName = sanitizeFileName(fileName, mimeTypeHint)
                    val mime = resolveMimeType(cleanName, mimeTypeHint)

                    val shareDir = File(cacheDir, "shared_files").apply { mkdirs() }
                    shareDir.listFiles()?.forEach { f ->
                        if (System.currentTimeMillis() - f.lastModified() > 3600_000L) f.delete()
                    }

                    val outFile = File(shareDir, cleanName)
                    FileOutputStream(outFile).use { it.write(bytes) }

                    val contentUri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "${packageName}.fileprovider",
                        outFile
                    )

                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, contentUri)
                        if (shareTitle.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, shareTitle)
                        if (shareText.isNotBlank()) putExtra(Intent.EXTRA_TEXT, shareText)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(sendIntent, shareTitle.ifBlank { "Share PDF Statement" }))
                } catch (e: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "Share error: ${e.localizedMessage}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun sharePlainText(title: String, text: String) {
            runOnUiThread {
                try {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    startActivity(Intent.createChooser(sendIntent, title.ifBlank { "Share" }))
                } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun startNativeSpeech(langCode: String) {
            runOnUiThread {
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode.ifBlank { "hi-IN" })
                        putExtra(RecognizerIntent.EXTRA_PROMPT, if (langCode.startsWith("hi")) "बोलिए..." else "Speak entry...")
                    }
                    speechRecognizerLauncher.launch(intent)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Voice recognition unavailable on device", Toast.LENGTH_SHORT).show()
                    webView.evaluateJavascript("window.__lpCancelSpeech && window.__lpCancelSpeech();", null)
                }
            }
        }

        @JavascriptInterface
        fun openServerUrlSettings() {
            runOnUiThread {
                showSetupOverlay(resolveConfiguredUrl())
            }
        }
    }

    private fun decodeDataUriOrBase64(raw: String): ByteArray {
        val commaIdx = raw.indexOf(',')
        val cleanB64 = if (commaIdx >= 0 && raw.substring(0, commaIdx).contains("base64")) {
            raw.substring(commaIdx + 1)
        } else {
            raw
        }
        return Base64.decode(cleanB64, Base64.DEFAULT)
    }

    private fun sanitizeFileName(name: String, mimeHint: String): String {
        val base = name.trim().replace(Regex("[\\\\/:*?\"<>|]+"), "_").ifBlank {
            if (mimeHint.contains("json")) "LedgerPro_Backup.json" else "LedgerPro_Statement.pdf"
        }
        return if (!base.contains('.')) {
            if (mimeHint.contains("json")) "$base.json" else "$base.pdf"
        } else {
            base
        }
    }

    private fun resolveMimeType(fileName: String, hint: String): String {
        if (hint.isNotBlank() && hint.contains("/")) return hint
        val lower = fileName.lowercase(Locale.ROOT)
        return when {
            lower.endsWith(".pdf") -> "application/pdf"
            lower.endsWith(".json") -> "application/json"
            else -> "application/octet-stream"
        }
    }

    private val bridgeBootstrapScript = """
        (function() {
          if (window.__ledgerProNativeHooked) return;
          window.__ledgerProNativeHooked = true;

          const blobStore = new Map();
          const origCreateObjUrl = URL.createObjectURL.bind(URL);
          URL.createObjectURL = function(obj) {
            const url = origCreateObjUrl(obj);
            if (obj instanceof Blob) {
              blobStore.set(url, obj);
              setTimeout(function() { blobStore.delete(url); }, 120000);
            }
            return url;
          };

          function sendBlobToNativeDownload(blob, filename) {
            const reader = new FileReader();
            reader.onloadend = function() {
              if (window.AndroidBridge && reader.result) {
                window.AndroidBridge.saveBase64ToDownloads(
                  String(reader.result),
                  filename || 'LedgerPro_Document.pdf',
                  blob.type || ''
                );
              }
            };
            reader.readAsDataURL(blob);
          }

          const origAnchorClick = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function() {
            const dlAttr = this.getAttribute('download');
            const dlName = (dlAttr !== null ? dlAttr : this.download) || '';
            const href = String(this.href || '');

            if (window.AndroidBridge && (dlAttr !== null || href.startsWith('blob:'))) {
              if (href.startsWith('data:')) {
                window.AndroidBridge.saveBase64ToDownloads(href, dlName || 'LedgerPro_Document.pdf', '');
                return;
              }
              if (href.startsWith('blob:')) {
                const cachedBlob = blobStore.get(href);
                if (cachedBlob) {
                  sendBlobToNativeDownload(cachedBlob, dlName || 'LedgerPro_Document.pdf');
                } else {
                  fetch(href).then(function(r) { return r.blob(); }).then(function(b) {
                    sendBlobToNativeDownload(b, dlName || 'LedgerPro_Document.pdf');
                  }).catch(function() {});
                }
                return;
              }
            }
            return origAnchorClick.apply(this, arguments);
          };

          navigator.canShare = function(data) {
            return Boolean(window.AndroidBridge && data);
          };

          navigator.share = function(data) {
            return new Promise(function(resolve, reject) {
              if (!window.AndroidBridge || !data) {
                reject(new Error('Share unavailable'));
                return;
              }
              if (data.files && data.files.length > 0) {
                const file = data.files[0];
                const reader = new FileReader();
                reader.onloadend = function() {
                  window.AndroidBridge.shareBase64File(
                    String(reader.result || ''),
                    file.name || 'LedgerPro_Statement.pdf',
                    file.type || 'application/pdf',
                    data.title || '',
                    data.text || ''
                  );
                  resolve();
                };
                reader.onerror = function() { reject(new Error('File read error')); };
                reader.readAsDataURL(file);
              } else {
                window.AndroidBridge.sharePlainText(data.title || '', data.text || data.url || '');
                resolve();
              }
            });
          };

          if (typeof window.SpeechRecognition === 'undefined' && typeof window.webkitSpeechRecognition === 'undefined') {
            window.__lpDeliverSpeech = function(spokenText) {
              const inst = window.__lpActiveSpeechInstance;
              if (!inst) return;
              if (typeof inst.onresult === 'function') {
                inst.onresult({ results: [[{ transcript: spokenText }]] });
              }
              if (typeof inst.onend === 'function') inst.onend();
              window.__lpActiveSpeechInstance = null;
            };
            window.__lpCancelSpeech = function() {
              const inst = window.__lpActiveSpeechInstance;
              if (!inst) return;
              if (typeof inst.onerror === 'function') inst.onerror({ error: 'cancelled' });
              if (typeof inst.onend === 'function') inst.onend();
              window.__lpActiveSpeechInstance = null;
            };
            window.webkitSpeechRecognition = function() {
              this.lang = 'hi-IN';
              this.interimResults = false;
              this.onresult = null;
              this.onend = null;
              this.onerror = null;
              this.start = function() {
                window.__lpActiveSpeechInstance = this;
                if (window.AndroidBridge) {
                  window.AndroidBridge.startNativeSpeech(this.lang || 'hi-IN');
                }
              };
              this.stop = function() {};
            };
          }
        })();
    """.trimIndent()
}
